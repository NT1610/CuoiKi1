package com.sortstrategy;

public class SortStrategy {
    private static SortStrategy instance;

    private ISort sortee;

    private SortStrategy() {

    }

    public static SortStrategy getInstance() {
        /* TODO */
    }

    public void setSortee(ISort sortee) {
        /* TODO */
    }

    public int sort(int[] data) {
        /* TODO */
    }
}
