public class TrapezoidalRule {
    public static void main (String[] args) {
        /* TODO */
    }
    
    public static double f(double x) {
        /* TODO */
    }
    
    public static double integrate(int n) {
        /* TODO */
    }
    
    public static double integrate() {
        /* TODO */
    }
}