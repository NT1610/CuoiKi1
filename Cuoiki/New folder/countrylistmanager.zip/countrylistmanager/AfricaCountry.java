package com.countrylistmanager;

public class AfricaCountry extends AbstractCountry {
    CountryData data;

    public AfricaCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
