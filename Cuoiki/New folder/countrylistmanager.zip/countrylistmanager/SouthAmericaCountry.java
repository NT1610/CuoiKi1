package com.countrylistmanager;

public class SouthAmericaCountry extends AbstractCountry {
    CountryData data;

    public SouthAmericaCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
