package com.countrylistmanager;

public class OceaniaCountry extends AbstractCountry {
    CountryData data;

    public OceaniaCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
