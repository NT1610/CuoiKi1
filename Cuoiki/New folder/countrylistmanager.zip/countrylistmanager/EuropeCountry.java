package com.countrylistmanager;

public class EuropeCountry extends AbstractCountry {
    CountryData data;

    public EuropeCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
