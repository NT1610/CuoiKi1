package com.countrylistmanager;

public class NorthAmericaCountry extends AbstractCountry {
    CountryData data;

    public NorthAmericaCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
