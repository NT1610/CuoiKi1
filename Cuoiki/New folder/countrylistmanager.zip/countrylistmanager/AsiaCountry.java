package com.countrylistmanager;

public class AsiaCountry extends AbstractCountry {
    CountryData data;

    public AsiaCountry(CountryData data) {
        this.data = data;
    }

    /* TODO */
}
